ApparelAdjuster.dll allows the clothing to never change colors no matter what material you use. 

If you don't want this to be applied with certain clothing but you want to keep the .dll, just remove the "<shaderType>CutoutComplex</shaderType>" code from the new clothing.